/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 *
 * @author DELL
 */
@WebServlet(urlPatterns = {"/Calc"})
public class Calc extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String a = request.getParameter("a");
            int c = Integer.parseInt(a);
            String b = request.getParameter("b");
            int d = Integer.parseInt(b);
            int sum = c+d;
            int sub = c-d;
            int pro = c*d;
            int div = c/d;
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Calc</title>");   
            out.println("<style> body {\n" +
"      font-family: Arial, sans-serif;\n" +
"      margin: 0;\n" +
"      padding: 0;\n" +
"      display: flex;\n" +
"      justify-content: center;\n" +
"      align-items: center;\n" +
"      min-height: 100vh;\n" +
"      background: linear-gradient(to bottom, #66ccff, #336699);\n" +
"    }\n" +
"\n" +
"    /* Style the container for your query solutions */\n" +
"    h1 {\n" +
"      font-size: 28px;\n" +
"      margin-bottom: 20px;\n" +
"      text-align: center;\n" +
"      color: white;\n" +
"      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);\n" +
"    }\n" +
"\n" +
"    /* Style the table */\n" +
"    table {\n" +
"      width: 80%;\n" +
"      margin: 0 auto;\n" +
"      border-collapse: collapse;\n" +
"      background-color: white;\n" +
"      border-radius: 10px;\n" +
"      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);\n" +
"    }\n" +
"\n" +
"    th, td {\n" +
"      padding: 10px;\n" +
"      text-align: center;\n" +
"    }\n" +
"\n" +
"    th {\n" +
"      background-color: #66ccff;\n" +
"      color: white;\n" +
"    }\n" +
"\n" +
"    tr:nth-child(even) {\n" +
"      background-color: #f2f2f2;\n" +
"    }\n" +
"\n" +
"    /* Animation keyframes */\n" +
"    @keyframes fadeInUp {\n" +
"      0% {\n" +
"        opacity: 0;\n" +
"        transform: translateY(20px);\n" +
"      }\n" +
"      100% {\n" +
"        opacity: 1;\n" +
"        transform: translateY(0);\n" +
"      }\n" +
"    }</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Your Query Solutions are: </h1>");
            out.println("<table>");
//            out.println("Sum: <span style=\"color: blue;\">" + sum+"</span>" );
//            out.println("Difference: <span style=\"color: green;\">" + sub +"</span>");
//            out.println("Product: <span style=\"color: orange;\">" + pro +"</span>");
//            out.println("Division: <span style=\"color: red;\">" + div +"</span>");
            out.println("<tr>\n" +
"      <th>Operation</th>\n" +
"      <th>Result</th>\n" +
"    </tr>\n" +
"    <tr>\n" +
"      <td>Sum</td>\n" +
"      <td><span style=\"color: blue;\">"+sum+"</span></td>\n" +
"    </tr>\n" +
"    <tr>\n" +
"      <td>Difference</td>\n" +
"      <td><span style=\"color: green;\">"+sub+"</span></td>\n" +
"    </tr>\n" +
"    <tr>\n" +
"      <td>Product</td>\n" +
"      <td><span style=\"color: orange;\">"+pro+"</span></td>\n" +
"    </tr>\n" +
"    <tr>\n" +
"      <td>Division</td>\n" +
"      <td><span style=\"color: red;\">"+div+"</span></td>\n" +
"    </tr>");
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    

}
